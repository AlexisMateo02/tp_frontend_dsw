/*se utiliza para mostrar la información detallada de un producto específico. 
En esta página, los usuarios pueden ver detalles como el nombre, descripción, imágenes, 
precio, características y, en muchos casos, opciones */
