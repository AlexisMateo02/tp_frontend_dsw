/* representa la "Home" o la vista inicial cuando se navega a esa ruta específica. */
import React from 'react';

function Index() {
  // Componente Index
  // Este componente representa la página de inicio de la aplicación.
  // Aquí se pueden incluir elementos como banners, promociones o información destacada.

  return <div> Index </div>;
}

export default Index;
