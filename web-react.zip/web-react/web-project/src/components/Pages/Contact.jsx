/* en esta página, los usuarios pueden encontrar información para comunicarse con los responsables 
del sitio, como formularios de contacto, direcciones de correo electrónico, teléfonos o 
enlaces a redes sociales.
*/
