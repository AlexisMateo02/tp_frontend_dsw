/*representa el componente que muestra la informacion sobre la pagina web,
por ejemplo en Quienes Somos?*/ 