/* Mostrar la tienda o catálogo de productos dentro de la aplicación. 
En esta página, los usuarios pueden ver los productos disponibles, sus descripciones, precios y, 
en muchos casos, añadirlos al carrito de compras o realizar una compra.*/