/* Se utiliza para mostrar información sobre las diferentes sucursales, tiendas físicas 
o puntos de venta relacionados con la aplicación o empresa. 
En esta página, los usuarios pueden encontrar direcciones, mapas, horarios de atención y 
datos de contacto de cada tienda.*/