/* Se utiliza para gestionar el proceso de pago o finalización de la compra. 
En esta página, los usuarios suelen ingresar sus datos de envío, seleccionar métodos de pago 
y confirmar la compra de los productos que tienen en el carrito.*/

