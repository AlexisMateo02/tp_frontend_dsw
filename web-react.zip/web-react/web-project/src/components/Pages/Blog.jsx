/*representa el componente que muestra las publicaciones o articulos dentro de la pagina web
permitiendo a los usuarios leer novedades, noticias o contenido relevante publicado 
por los autores del sitio.*/