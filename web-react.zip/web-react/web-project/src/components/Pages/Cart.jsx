/* Para mostrar el carrito de compras dentro de la pagina web 
En esta página, los usuarios pueden ver los productos que han añadido al carrito, 
modificar cantidades, eliminar productos y proceder al pago o finalizar la compra.*/