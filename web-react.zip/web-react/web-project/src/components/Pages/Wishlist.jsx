/* Se utiliza para mostrar la lista de deseos del usuario. */
