import React from 'react'; //Importa libreria React
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; //Importa Bootstrap JS para funcionalidades interactivas

function Nav() {
  //Componente Nav
  // Este componente representa la barra de navegación principal de la aplicación.
  // Contiene enlaces a diferentes secciones y funcionalidades de la aplicación.

  return (
    <>
      {/* Navbar principal */}
      <div className="nav w-100 fixed-top bd-white shadow-sm">
        <nav className="navbar navbar-expand-lg py-3 justify-content-between align-items-center w-100 nav-wrapper">
          {/* Toggle button */}
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          {/* Mobile Logo */}
          <a href="#" className="navbar-brand mx-auto order-0 d-lg-none d-flex">
            <h2 className="m-0 fw-bold" style={{ letterSpacing: '2px' }}>
              {' '}
              KAYAKS BROKERS
            </h2>
          </a>

          {/* Mobile Icons */}
          <ul className="d-lg-none d-flex align-items-center gap-3">
            <li className="nav-item">
              <a href="#">
                <i className="bi bi-search fs-5 text-dark"></i>
              </a>
            </li>
            <li className="nav-item">
              <a href="#" data-bs-toggle="modal" data-bs-target="#SignUpModal">
                <i className="bi bi-person fs-5 text-dark"></i>
              </a>
            </li>
            <li className="nav-item position-relative">
              <a href="#">
                <i className="bi bi-heart fs-5 text-dark"></i>
                <span className="position-absolute top-@ start-10@ translate-middle cart-qount rounded-pill">
                  0
                </span>
              </a>
            </li>
            <li className="nav-item position-relative">
              <a href="#">
                <i className="bi bi-bag fs-5 text-dark"></i>
                <span className="position-absolute top-@ start-10@ translate-middle cart-qount rounded-pill">
                  0
                </span>
              </a>
            </li>
          </ul>

          {/* Main Nav */}
          <div
            className="collapse navbar-collapse justify-content-between"
            id="navbarNav"
          >
            {/* Left Nav */}
            <ul className="navbar-nav nav-menu align-items-center gap-4">
              <li className="nav-item">
                <a href="#" className="nav-link">
                  Inicio
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  Quienes Somos?
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  Productos
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  Accesorios
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  Contactos
                </a>
              </li>
            </ul>
            {/* Center Logo */}
            <a href="#" className="navbar-brand order-@ d-none d-lg-flex">
              <h2 className="m-@ fw-bold" style={{ letterSpacing: '2px' }}>
                KAYAKS BROKERS
              </h2>
            </a>

            {/* Right Icons */}
            <ul className="navbar-nav d-none d-lg-flex align-items-center gap-4">
              <li className="nav-item">
                <a href="#">
                  <i className="bi bi-search fs-5 text-dark"></i>
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="#"
                  data-bs-toggle="modal"
                  data-bs-target="#SignUpModal"
                >
                  <i className="bi bi-person fs-5 text-dark"></i>
                </a>
              </li>
              <li className="nav-item position-relative">
                <a href="#">
                  <i className="bi bi-heart fs-5 text-dark"></i>
                  <span className="position-absolute top-@ start-10@ translate-middle cart-qount rounded-pill">
                    0
                  </span>
                </a>
              </li>
              <li className="nav-item position-relative">
                <a href="#">
                  <i className="bi bi-bag fs-5 text-dark"></i>
                  <span className="position-absolute top-@ start-10@ translate-middle cart-qount rounded-pill">
                    0
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </div>

      {/*Sign Up Modal*/}
      <div
        className="modal fade"
        id="SignUpModal"
        tabIndex="-1"
        aria-labelledby="SignUpModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content p-4">
            <div className="modal-header border-0">
              <h5 className="modal-title fw-bold" id="SignUpModalLabel">
                Ingresa con su cuenta
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <form>
                <div className="mb-3">
                  <label className="form-label">Usuario</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Ingresa tu nombre"
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Ingresa correo electronico"
                    required
                  />
                  <label className="form-label">Contraseña</label>
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Ingresa contraseña"
                    required
                  />
                </div>
                <p className="text-muted">
                  Al ingresar, aceptas nuestros&nbsp;
                  <a href="#" className="text-success text-decoration-none">
                    Términos
                  </a>
                  &nbsp;y&nbsp;
                  <a href="#" className="text-success text-decoration-none">
                    Política de Privacidad
                  </a>
                  .
                </p>

                <button type="button" className="btn btn-dark w-100">
                  Ingresar
                </button>
              </form>
              <div className="text-center mt-3">
                <p>
                  Ya tiene una cuenta?
                  <a href="#" className="text-success fw-bold">
                    {' '}
                    Registrarse
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Nav;
