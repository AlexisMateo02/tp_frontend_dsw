import './App.css';
import Nav from './components/Nav/Nav.jsx';
import Index from './components/Pages/Index.jsx';

function App() {
  return (
    <>
      <Nav />
      <Index />
    </>
  );
}

export default App;
